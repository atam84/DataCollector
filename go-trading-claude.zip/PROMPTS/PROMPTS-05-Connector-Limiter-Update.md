# PROMPTS — Implementation Update: One Public Connector per Exchange + Rate-Limit Tokens (per API request)

**Document:** PROMPTS-05-Connector-Limiter-Update  
**Version:** 1.0  
**Date:** 2026-01-18  
**Purpose:** Provide **full, detailed prompts** to drive implementation updates for the new model:
- **1 public connector per exchange** (MongoDB)
- **Jobs stored in MongoDB** (definitions + runtime state)
- **Rate-limit usage increments per external API request** (token-based, exchange-wide)
- **Resumable jobs** for pagination/backfill with cursor persistence

---

## Global Context (use in every prompt)

### Stack & Constraints
- Backend: **Golang**
- Exchange library: **CCXT for Go** (public endpoints only; no auth)
- Storage: **MongoDB**
- Connector rule: **exactly one connector per exchange**
- Rate limit: enforced **per API request** using connector-wide tokens (Option B)
- Jobs: stored in `jobs` collection; executed by worker(s) with locking
- Data integrity: OHLCV is **idempotent upsert** using unique key `(exchange_id, symbol, timeframe, timestamp)`
- No background promises: deliver complete outputs in one response per prompt
- Prefer clear module boundaries and testability

### Definitions
- **Connector** = exchange controller + limiter state
- **Job** = scheduled/resumable work item (incremental/backfill/gap/markets)
- **Token** = 1 allowed external API request within the current connector window
- **Cursor** = job checkpoint for resuming long runs

### Collections (target)
- `connectors`: one doc per exchange (unique index on `exchange_id`)
- `jobs`: job definitions + runtime state and lock fields
- Existing OHLCV collections remain (do not break current read APIs)

### Acceptance Baseline
- Under concurrency, `rate_limit_usage` never exceeds `rate_limit` in a window.
- Any job that needs multiple requests pauses/resumes cleanly without duplicates.
- Creating same exchange connector is idempotent and returns the existing connector.

---

# Prompt 1 — Data Model + Indexes (Mongo)

**Role:** You are a senior backend engineer.  
**Task:** Propose and implement the MongoDB schemas and indexes for `connectors` and `jobs` collections.

## Requirements
1. `connectors` schema must include:
   - exchange identifier (`exchange_id`), creation_date, status
   - rate_limit_period_ms, rate_limit, rate_limit_usage
   - rate_limit_window_start, rate_limit_reset_at
   - last_job_run_time, jobs_count, active_jobs_count
2. `jobs` schema must include:
   - exchange_id, type, symbol, timeframe
   - status, state
   - schedule (interval-based), next_run_at, priority
   - cursor (since_ms, until_ms, last_ts, page, done)
   - stats (runs/success/fail/last_*)
   - lock fields (locked_by, lock_until)
3. Indexes:
   - Unique index on `connectors.exchange_id`
   - Scheduling index on jobs: `{status, state, next_run_at, priority}`
   - Optional partial unique index to prevent duplicate active incremental jobs per `(exchange_id,type,symbol,timeframe)`

## Deliverables
- Markdown: schema definition + field meanings
- Mongo shell commands for indexes
- A Go migration/init function that ensures indexes exist (idempotent)

## Output format
- Provide: `schemas.md` excerpt + Go code snippets

---

# Prompt 2 — ConnectorManager Module (EnsureConnector + AcquireToken)

**Role:** Senior Go engineer.  
**Task:** Create a `ConnectorManager` package with idempotent connector creation and safe token acquisition.

## Functions
1. `EnsureConnector(exchange_id string, defaults Defaults) (Connector, error)`
   - Upsert by `exchange_id`
   - If exists, return existing
   - If created, initialize limiter window fields
2. `AcquireToken(exchange_id string, nowMs int64) (ok bool, retryAfterMs int64, err error)`
   - Option B: increment usage per API request
   - Must be concurrency-safe with Mongo atomic updates
   - Use **two-attempt** atomic pattern:
     - Attempt A: reset window if expired and consume 1 token
     - Attempt B: consume within active window if usage < limit
   - If no token: compute `retryAfterMs` using `rate_limit_reset_at - nowMs`

## Requirements
- No race conditions under multiple workers
- Must handle missing connector gracefully (auto EnsureConnector optional)
- Include unit tests (use Mongo test container or mocking abstraction)

## Deliverables
- Go package structure proposal
- Code: `connector_manager.go`
- Tests: `connector_manager_test.go`
- Notes: how to tune defaults from CCXT exchange rateLimit

---

# Prompt 3 — Job Scheduler & Query (next runnable job)

**Role:** Backend engineer.  
**Task:** Implement job selection logic that respects priority, schedule, and states.

## Job selection rules
- Eligible jobs:
  - `status = "active"`
  - `state in ["idle","queued","waiting_rate_limit"]`
  - `next_run_at <= now`
- Sort by:
  1. `priority` ascending
  2. `next_run_at` ascending
- Lock job using atomic update (findOneAndUpdate):
  - set `state="running"`
  - set `lock.locked_by=workerId`, `lock.lock_until=now+TTL`
- If job lock expired, allow stealing

## Deliverables
- Go code: `job_repository.go` with `FindAndLockNextJob(...)`
- Mongo query examples
- Tests: concurrent lock acquisition behavior

---

# Prompt 4 — Worker Execution Loop (token-per-request + pause/resume)

**Role:** Senior systems engineer.  
**Task:** Implement worker loop that executes jobs and never violates rate limits.

## Requirements
- Before every CCXT call: `AcquireToken(exchange_id)`
- If token unavailable:
  - update job `state="waiting_rate_limit"`
  - set `next_run_at = now + retryAfterMs` (or exactly reset_at)
  - release lock (`lock_until=null`, `locked_by=null`)
  - stop job execution cleanly
- Backfill and gap jobs must persist cursor after each page request
- Incremental jobs should be fast and typically 1 request/run, but still token gated
- Ensure idempotent OHLCV upsert prevents duplicates

## Deliverables
- Go code: `worker.go` (core loop)
- Job handler interface: `JobHandler.Handle(job)`
- Detailed logging strategy and metrics hooks
- Tests: worker pauses on rate limit, resumes from cursor

---

# Prompt 5 — Job Handlers (markets_refresh, ohlcv_incremental, ohlcv_backfill, gap_backfill)

**Role:** Data pipeline engineer.  
**Task:** Implement each job type as a handler.

## Common requirements
- Use CCXT-Go public endpoints only
- Validate timeframe supported by exchange before executing
- Use stable time alignment (latest closed candle for timeframes)

### Handler: markets_refresh
- Fetch markets/timeframes; store snapshot; update `updated_at`

### Handler: ohlcv_incremental
- Read metadata for last candle
- Fetch candles since `last_ts + timeframe_ms`
- Upsert OHLCV
- Update metadata last_ts, last_success_at

### Handler: ohlcv_backfill
- Use cursor.since_ms (start at earliest available if 0)
- Pagination loop with per-request token acquisition
- Persist cursor after each page
- Stop conditions: <limit, reached now, exchange boundary, safety cap
- Mark cursor.done=true and state success

### Handler: gap_backfill
- Use cursor.until_ms as boundary
- Similar loop but constrained to gap range
- Mark success and optionally delete job

## Deliverables
- Go files per handler
- Cursor schema usage examples
- Edge case handling: empty response, overlapping candles, server time drift

---

# Prompt 6 — Update All CCXT Call Sites (Hard Gate)

**Role:** Lead engineer doing refactor.  
**Task:** Identify and wrap **every** CCXT call site with token acquisition.

## Requirements
- Create a helper like: `DoExchangeCall(exchange_id, fn)` that acquires token and executes
- Ensure:
  - fetchMarkets
  - fetchOHLCV
  - any other public call in code base is gated
- If token unavailable, propagate a structured error that job handler uses to pause/reschedule

## Deliverables
- A list of call sites found and patched (file paths)
- Refactored helper and usage examples
- Regression tests ensuring no direct CCXT calls bypass gating

---

# Prompt 7 — API Changes (Connectors become upsert; Streams become Jobs)

**Role:** API designer.  
**Task:** Update REST API to match the new model.

## Requirements
- `POST /connectors` becomes idempotent upsert by `exchange_id`
- Add endpoints for jobs:
  - Create job (incremental/backfill)
  - Pause/resume job
  - Run now
  - List jobs filtered by exchange/symbol/timeframe/type
- Add endpoints to view limiter state per exchange:
  - rate_limit_usage, reset_at, saturation events

## Deliverables
- Updated OpenAPI/Swagger excerpt (or markdown endpoint list)
- Request/response examples (JSON)
- Notes about backward compatibility for existing UI

---

# Prompt 8 — Migration Script/Procedure (Old → New)

**Role:** DevOps + backend.  
**Task:** Provide a safe migration plan and optional script.

## Requirements
- Create indexes (idempotent)
- For each existing exchange configuration:
  - upsert connector doc
- For each existing pair/timeframe schedule:
  - create `ohlcv_incremental` job (idempotent; unique partial index helps)
  - create `ohlcv_backfill` job if metadata indicates missing history
- Ensure no data deletion
- Provide rollback strategy

## Deliverables
- Migration steps (markdown)
- Go script command entrypoint `cmd/migrate_connectors_jobs`
- Verification queries to validate migration

---

# Prompt 9 — Concurrency & Correctness Tests (must-have)

**Role:** QA/automation engineer.  
**Task:** Build a suite of tests to ensure no rate-limit overruns and correct job behavior.

## Test cases
1. **Token saturation**: many goroutines calling AcquireToken concurrently
2. **Window reset**: usage resets correctly at period boundary
3. **Backfill pause/resume**: job pauses at limit, resumes later, completes without duplicates
4. **Job lock**: two workers cannot run same job simultaneously; lock stealing works after expiry
5. **Idempotent OHLCV upsert**: duplicates not created under replays/overlaps

## Deliverables
- Test plan (markdown)
- Go tests and any helpers/mocks
- How to run tests locally/CI

---

# Prompt 10 — Observability (metrics + logs)

**Role:** SRE-minded engineer.  
**Task:** Add metrics and structured logs for the new system.

## Metrics
- per exchange:
  - requests_total, requests_denied_total, limiter_usage_current, limiter_reset_at
- per jobs:
  - jobs_running, jobs_waiting_rate_limit, jobs_failed
- latency histograms for CCXT calls

## Logs
- Job lifecycle logs (start/end/pause/fail)
- Rate limit events with retryAfterMs
- Cursor checkpoints for backfills

## Deliverables
- Prometheus metrics list + sample Grafana panels
- Logging fields format (JSON structured)
- Alert rules (basic): stuck jobs, frequent limiter denials, repeated failures

---

# Prompt 11 — Documentation Update (PRD/ARCH alignment)

**Role:** Technical writer + engineer.  
**Task:** Update project docs to reflect the new connector/job model.

## Must include
- One connector per exchange rule
- Per-request token limiter
- Job states and transitions
- Cursor-based resumable backfill
- How UI maps to connector/jobs

## Deliverables
- Updated sections for PRD + backend architecture doc
- A short “How it works” workflow diagram (mermaid)

---

## Quick Copy-Paste Template (use for any of the prompts above)

> **Context:** We are updating the Data Collector backend in Go using CCXT-Go and MongoDB to implement exactly one public connector per exchange and enforce exchange-wide rate limiting per API request. Jobs are stored in MongoDB with locking and cursors for resumable execution.  
> **Task:** (paste prompt title + requirements)  
> **Deliverables:** (paste deliverables list)  
> **Acceptance Criteria:** Must never exceed rate_limit within rate_limit_period; backfill is resumable; connector upsert is idempotent; all CCXT calls are gated.

---
