# PROMPTS-04: Phase 4 - Polish

## Document Information

| Field | Value |
|-------|-------|
| **Phase** | 4 - Polish |
| **Weeks** | 13-16 |
| **Focus** | Monitoring, alerting, performance optimization, documentation, testing |

---

## Week 13: Monitoring & Alerting

### MO-001 to MO-008: Monitoring Implementation

```
Implement comprehensive monitoring for the Data Collector.

Requirements:
1. Create internal/metrics/metrics.go with Prometheus metrics:

import (
    "github.com/prometheus/client_golang/prometheus"
    "github.com/prometheus/client_golang/prometheus/promauto"
)

var (
    // Collection metrics
    CandlesCollected = promauto.NewCounterVec(
        prometheus.CounterOpts{
            Namespace: "data_collector",
            Name:      "candles_collected_total",
            Help:      "Total number of candles collected",
        },
        []string{"exchange", "pair", "timeframe"},
    )
    
    CollectionDuration = promauto.NewHistogramVec(
        prometheus.HistogramOpts{
            Namespace: "data_collector",
            Name:      "collection_duration_seconds",
            Help:      "Duration of collection operations",
        },
        []string{"exchange", "type"},
    )
    
    // Rate limit metrics
    RateLimitWaits = promauto.NewCounterVec(...)
    
    // Queue metrics
    JobQueueSize = promauto.NewGauge(...)
    JobsProcessed = promauto.NewCounterVec(...)
    
    // Circuit breaker metrics
    CircuitBreakerState = promauto.NewGaugeVec(...)
    
    // WebSocket metrics
    WebSocketConnections = promauto.NewGauge(...)
    
    // Database metrics
    DBQueryDuration = promauto.NewHistogramVec(...)
)

2. Integrate metrics into all components

3. Create metrics endpoint:
   GET /metrics (Prometheus format)

4. Create Grafana dashboards:
   - Collection Overview
   - Exchange Health
   - System Performance

5. Create health check service:

type HealthStatus struct {
    Status     string                      `json:"status"`
    Components map[string]ComponentHealth  `json:"components"`
    Timestamp  time.Time                   `json:"timestamp"`
}

6. Add structured logging with correlation IDs

Please provide complete metrics implementation.
```

---

### AL-001 to AL-008: Alerting Implementation

```
Implement alerting system for the Data Collector.

Requirements:
1. Create internal/models/alert.go:

type AlertSeverity string
const (
    AlertSeverityInfo     AlertSeverity = "info"
    AlertSeverityWarning  AlertSeverity = "warning"
    AlertSeverityCritical AlertSeverity = "critical"
)

type AlertType string
const (
    AlertTypeCollectionFailed AlertType = "collection_failed"
    AlertTypeGapDetected      AlertType = "gap_detected"
    AlertTypeExchangeDown     AlertType = "exchange_down"
    AlertTypeRateLimited      AlertType = "rate_limited"
    AlertTypeHighErrorRate    AlertType = "high_error_rate"
)

type Alert struct {
    ID             uuid.UUID     `json:"id"`
    Type           AlertType     `json:"type"`
    Severity       AlertSeverity `json:"severity"`
    Title          string        `json:"title"`
    Message        string        `json:"message"`
    Exchange       *string       `json:"exchange,omitempty"`
    ConnectorID    *uuid.UUID    `json:"connector_id,omitempty"`
    Status         AlertStatus   `json:"status"`
    CreatedAt      time.Time     `json:"created_at"`
    AcknowledgedAt *time.Time    `json:"acknowledged_at,omitempty"`
    ResolvedAt     *time.Time    `json:"resolved_at,omitempty"`
}

2. Create alert repository and service

3. Create alert rules engine with conditions

4. Integrate with event bus:
   - Subscribe to CollectionFailed
   - Subscribe to GapDetected
   - Subscribe to CircuitBreakerTripped

5. Create API endpoints:
   - GET /api/v1/alerts
   - POST /api/v1/alerts/:id/acknowledge
   - POST /api/v1/alerts/:id/resolve

6. Create alert UI components:
   - AlertBanner (for critical alerts)
   - AlertsPage (management)

Please provide complete implementation.
```

---

## Week 14: Performance Optimization

### BO-001 to BO-008: Backend Optimization

```
Optimize backend performance for the Data Collector.

Requirements:
1. Profile API endpoints:
   - Add pprof endpoints (development only)
   - Run CPU and memory profiling
   - Identify bottlenecks

2. Optimize MongoDB queries:
   - Create compound indexes
   - Use projection for needed fields only
   - Use hints to force index usage
   - Batch reads for large datasets

3. Implement query result caching:

type CacheLayer struct {
    cache  *cache.Cache
    ttl    time.Duration
}

func (c *CacheLayer) Get(key string, fetcher func() (interface{}, error)) (interface{}, error)

4. Optimize bulk operations:
   - Use bulk write with ordered=false
   - Batch size optimization

5. Tune connection pools:
   - MongoDB: max/min pool size
   - PostgreSQL: max/min connections

6. Add response compression:
   - Enable gzip middleware

7. Implement request batching for data queries

8. Run load tests with k6:
   - 50 concurrent users
   - 5 minute duration
   - Measure p95 < 200ms

Please provide optimization code and benchmark results.
```

---

### FO-001 to FO-008: Frontend Optimization

```
Optimize frontend performance for the Data Collector.

Requirements:
1. Implement chart virtualization:
   - Use react-window for large tables
   - Virtual rendering for chart data

2. Implement data downsampling:

export function downsampleOHLCV(
  data: OHLCV[],
  maxPoints: number
): OHLCV[] {
  if (data.length <= maxPoints) return data;
  
  const step = Math.ceil(data.length / maxPoints);
  // Aggregate OHLC properly for each chunk
}

3. Optimize re-renders:
   - Use React.memo for expensive components
   - Use useMemo for expensive calculations
   - Use useCallback for event handlers

4. Add code splitting:
   - Lazy load pages
   - Manual chunks for vendor, charts, ui

5. Optimize bundle size:
   - Analyze with vite-bundle-visualizer
   - Replace heavy dependencies
   - Tree-shake lodash

6. Add service worker caching:
   - Use vite-plugin-pwa
   - Cache static assets
   - Cache API responses

7. Run Lighthouse audits:
   - Target performance score > 90
   - Fix identified issues

8. Create performance budget:
   - First Contentful Paint < 2s
   - Time to Interactive < 3.5s
   - Bundle size < 500KB gzipped

Please provide optimization code and metrics.
```

---

## Week 15: Documentation & Testing

### DO-001 to DO-008: Documentation

```
Create comprehensive documentation for the Data Collector.

Requirements:
1. Create docs/openapi.yaml (OpenAPI 3.0):
   - All endpoints documented
   - Request/response schemas
   - Examples
   - Error responses

2. Create docs/deployment.md:
   - Prerequisites
   - Docker deployment
   - Kubernetes deployment
   - Environment variables
   - Health checks

3. Create docs/configuration.md:
   - All configuration options
   - Environment variable overrides
   - Examples

4. Create docs/user-manual.md:
   - Getting started
   - Creating connectors
   - Managing data collection
   - Using the explorer
   - Exporting data

5. Create docs/database-schema.md:
   - PostgreSQL tables
   - MongoDB collections
   - Indexes
   - Relationships

6. Create docs/troubleshooting.md:
   - Common issues
   - Error codes
   - Debug steps

7. Create README.md for each component

Please provide complete documentation files.
```

---

### TE-001 to TE-008: Testing

```
Implement comprehensive testing for the Data Collector.

Requirements:
1. Increase unit test coverage to 80%:
   - Test all public methods
   - Test edge cases
   - Mock external dependencies

2. Write integration tests:
   - Use testcontainers for databases
   - Test full flows
   - Test error scenarios

3. Write E2E tests with Playwright:
   - Connector CRUD flow
   - Data explorer flow
   - Export flow

4. Run load tests:
   - k6 scripts for API endpoints
   - Measure throughput and latency
   - Test sustained load

5. Perform security testing:
   - OWASP ZAP scan
   - govulncheck for Go
   - npm audit for frontend

6. Run chaos testing:
   - Kill database connections
   - Inject network latency
   - Simulate exchange failures

7. Fix all identified issues

8. Create test reports

Please provide test files and reports.
```

---

## Week 16: Bug Fixes & Final Polish

### BF-001 to BF-005: Bug Fixes

```
Process for triaging and fixing bugs.

Bug Triage Process:
1. Collect bugs from:
   - Manual testing
   - E2E test failures
   - Load test issues
   - Security findings

2. Categorize by severity:
   - Critical: Data loss, security, crashes
   - High: Major functionality broken
   - Medium: Feature partially broken
   - Low: Minor issues

3. Prioritize by impact × effort

Bug Report Template:
## Bug Report
**Title:** [Brief description]
**Severity:** [Critical/High/Medium/Low]
**Steps to Reproduce:**
1. ...
**Expected Behavior:**
**Actual Behavior:**
**Screenshots/Logs:**

Bug Fix Process:
1. Create branch from main
2. Write failing test
3. Fix the bug
4. Verify test passes
5. Code review
6. Merge and verify

Please follow this process for all bugs.
```

---

### FP-001 to FP-008: Final Polish

```
Final polish tasks before release.

Requirements:
1. UI/UX review checklist:
   - [ ] Consistent spacing and typography
   - [ ] Color contrast meets WCAG AA
   - [ ] Loading states for all async operations
   - [ ] Error states with helpful messages
   - [ ] Empty states with guidance
   - [ ] Responsive on all screen sizes

2. Accessibility audit:
   - Run axe-core
   - Test with screen reader
   - Test keyboard navigation
   - Test color blindness simulation

3. Cross-browser testing:
   - Chrome, Firefox, Safari, Edge
   - Mobile Chrome, Safari iOS

4. Mobile responsiveness:
   - iPhone SE, iPhone 14, iPad
   - Desktop 1280px+, 1920px+

5. Final security review:
   - No sensitive data in logs
   - No hardcoded secrets
   - Input validation
   - Rate limiting
   - CORS configuration

6. Performance final check:
   - Lighthouse > 90
   - API p95 < 200ms
   - Bundle < 500KB

7. Prepare release notes:
   - Features
   - Supported exchanges
   - Known issues
   - Breaking changes

8. Production deployment prep:
   - Environment variables documented
   - Database migrations ready
   - Rollback plan
   - Monitoring dashboards
   - Runbook created

Please complete all checklist items.
```

---

## Appendix: Useful Prompt Templates

### Debugging Prompt

```
I'm experiencing the following issue with [COMPONENT]:

**Error Message:**
[Paste error]

**Code Context:**
[Paste relevant code]

**Steps Taken:**
1. [What I've tried]

**Expected vs Actual:**
Expected: [What should happen]
Actual: [What happens]

Please help me:
1. Understand what's causing this
2. Provide a fix
3. Explain how to prevent this in the future
```

---

### Refactoring Prompt

```
Please refactor the following code for better:
- Readability
- Performance
- Testability
- Maintainability

Current code:
[Paste code]

Requirements:
- Maintain same functionality
- Follow best practices
- Add error handling
- Include comments

Please provide:
1. Refactored code
2. Explanation of changes
3. Any trade-offs
```

---

### Code Generation Prompt

```
Generate [LANGUAGE] code for [FUNCTIONALITY].

Requirements:
- [Requirement 1]
- [Requirement 2]
- [Requirement 3]

Constraints:
- Must work with [framework]
- Must handle [edge cases]

Include:
- Type definitions
- Error handling
- Unit tests
- Documentation
```

---

## Quick Reference

| Phase | Weeks | Focus | Key Deliverables |
|-------|-------|-------|------------------|
| 1 - Foundation | 1-4 | Setup | Project structure, CCXT, CRUD, Storage |
| 2 - Core | 5-8 | Features | Rate limits, Scheduling, Dashboard |
| 3 - Enrichment | 9-12 | Value-add | Indicators, WebSocket, Charts, Export |
| 4 - Polish | 13-16 | Quality | Monitoring, Performance, Docs, Testing |

**Total estimated time: 16 weeks**
**Total tasks: 304**

---

*End of Prompts Documentation*
