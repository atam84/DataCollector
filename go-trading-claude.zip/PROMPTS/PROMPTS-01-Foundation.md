# PROMPTS-01: Phase 1 - Foundation

## Document Information

| Field | Value |
|-------|-------|
| **Phase** | 1 - Foundation |
| **Weeks** | 1-4 |
| **Focus** | Project setup, CCXT integration, Connector CRUD, Data storage |

---

## Week 1: Project Setup & Infrastructure

### BE-001: Initialize Go Module and Project Structure

```
Create a new Go project for the Data Collector backend service.

Requirements:
1. Initialize Go module with name "github.com/gotrading/data-collector"
2. Use Go 1.22+
3. Create the following directory structure:

data-collector-backend/
├── cmd/
│   └── server/
│       └── main.go
├── internal/
│   ├── api/
│   │   ├── handlers/
│   │   ├── middleware/
│   │   ├── websocket/
│   │   ├── router.go
│   │   └── server.go
│   ├── services/
│   ├── core/
│   ├── repository/
│   ├── models/
│   └── config/
├── pkg/
│   ├── logger/
│   ├── validator/
│   └── utils/
├── migrations/
├── scripts/
├── deployments/
├── configs/
├── go.mod
└── README.md

4. Create a basic main.go that prints "Data Collector Starting..."
5. Add a .gitignore file for Go projects
6. Create a basic README.md with project description

Please provide the complete file contents for each file.
```

---

### BE-002: Set Up Fiber Framework with Middleware

```
Set up the Fiber web framework for the Data Collector backend.

Requirements:
1. Install Fiber v2: go get github.com/gofiber/fiber/v2
2. Create internal/api/server.go with:
   - Server struct with Fiber app instance
   - NewServer function that creates and configures the Fiber app
   - Start method that listens on configured port
   - Shutdown method for graceful shutdown

3. Create internal/api/router.go with:
   - SetupRoutes function that registers all routes
   - API versioning under /api/v1
   - Group routes by resource (connectors, exchanges, data, etc.)

4. Create internal/api/middleware/ with:
   - logging.go - Request logging middleware
   - recovery.go - Panic recovery middleware
   - cors.go - CORS configuration
   - requestid.go - Request ID middleware

5. Configure middleware in order:
   - Recovery (first)
   - Request ID
   - Logger
   - CORS

6. Add a health check endpoint at GET /health

Please provide complete implementation with error handling.
```

---

### BE-003: Configure Viper for Configuration Management

```
Set up Viper for configuration management in the Data Collector backend.

Requirements:
1. Install Viper: go get github.com/spf13/viper
2. Create internal/config/config.go with:

Config struct containing:
- Server: host, port, readTimeout, writeTimeout
- MongoDB: uri, database, maxPoolSize, minPoolSize
- PostgreSQL: host, port, database, user, password, maxConnections
- Collector: workers, batchSize, backfillEnabled
- Indicators: autoCompute, workers, defaultConfig
- RateLimits: default and per-exchange limits
- WebSocket: bufferSizes, pingInterval
- Logging: level, format, output
- Metrics: enabled, port

3. Implement:
- Load() function that reads from config file and environment
- Validate() function that validates required fields
- Support environment variable overrides with DATACOLLECTOR_ prefix

4. Create configs/config.yaml with default values
5. Create configs/config.development.yaml with development overrides

Please provide complete implementation with documentation comments.
```

---

### BE-004: Set Up Zerolog for Structured Logging

```
Set up Zerolog for structured logging in the Data Collector backend.

Requirements:
1. Install Zerolog: go get github.com/rs/zerolog
2. Create pkg/logger/logger.go with:

- Logger interface with methods:
  - Debug(msg string, fields ...Field)
  - Info(msg string, fields ...Field)
  - Warn(msg string, fields ...Field)
  - Error(msg string, err error, fields ...Field)
  - Fatal(msg string, err error, fields ...Field)
  - With(fields ...Field) Logger

- Field type for structured logging fields
- Helper functions: String, Int, Bool, Time, Duration, Any, Err

- NewLogger(config LogConfig) function that:
  - Configures output (stdout/file)
  - Sets log level
  - Configures format (JSON/pretty)
  - Adds default fields (service name, version)

3. Create middleware that injects logger into Fiber context
4. Create helper to extract logger from context

Please provide complete implementation.
```

---

### BE-005: Create Docker and Docker-Compose Files

```
Create Docker configuration for the Data Collector service.

Requirements:
1. Create deployments/docker/Dockerfile with:
   - Multi-stage build
   - golang:1.22-alpine as builder
   - alpine:3.19 as final image
   - Non-root user
   - Health check

2. Create docker-compose.yml with services:
   - data-collector (the Go service)
   - mongodb (MongoDB 7)
   - postgres (PostgreSQL 16)
   - mongo-express (optional, for debugging)
   - pgadmin (optional, for debugging)

3. Configure:
   - Volume mounts for data persistence
   - Network configuration
   - Environment variables
   - Health checks for all services
   - Dependency ordering

4. Create docker-compose.override.yml for development
5. Create .dockerignore file

Please provide complete files with comments.
```

---

### BE-006: Set Up MongoDB Connection and Client

```
Set up MongoDB connection for the Data Collector backend.

Requirements:
1. Install MongoDB driver: go get go.mongodb.org/mongo-driver/mongo
2. Create internal/repository/mongo/client.go with:

- MongoClient struct containing:
  - *mongo.Client
  - *mongo.Database
  - Collection getters

- NewMongoClient(config MongoConfig) function that:
  - Creates connection with proper options
  - Sets up connection pool (min/max)
  - Configures timeouts
  - Enables compression

- Connect(ctx context.Context) error
- Disconnect(ctx context.Context) error
- Ping(ctx context.Context) error
- Database() *mongo.Database
- Collection(name string) *mongo.Collection

3. Implement connection retry with exponential backoff
4. Create health check function
5. Create helper functions for getting OHLCV collections

Please provide complete implementation with proper error handling.
```

---

### BE-007: Set Up PostgreSQL Connection with pgx

```
Set up PostgreSQL connection using pgx for the Data Collector backend.

Requirements:
1. Install pgx: go get github.com/jackc/pgx/v5
2. Create internal/repository/postgres/client.go with:

- PostgresClient struct containing:
  - *pgxpool.Pool

- NewPostgresClient(config PostgresConfig) function that:
  - Builds connection string
  - Creates connection pool
  - Configures pool size (min/max)
  - Sets timeouts

- Connect(ctx context.Context) error
- Close()
- Ping(ctx context.Context) error
- Pool() *pgxpool.Pool

3. Implement connection retry with exponential backoff
4. Create transaction helper:
   func (c *PostgresClient) WithTx(ctx context.Context, fn func(tx pgx.Tx) error) error

Please provide complete implementation with proper error handling.
```

---

### BE-008: Create Database Migration System

```
Create a database migration system for PostgreSQL.

Requirements:
1. Install golang-migrate: go get github.com/golang-migrate/migrate/v4
2. Create migrations/postgres/ directory for SQL migrations
3. Create internal/repository/postgres/migrator.go with:

- Migrator struct
- NewMigrator(db *PostgresClient, migrationsPath string) function
- Up(ctx context.Context) error - run all pending migrations
- Down(ctx context.Context) error - rollback last migration
- Version() (int, bool, error) - get current version

4. Create initial migrations:

migrations/postgres/001_create_connectors.up.sql:
- connectors table with all fields
- Indexes
- Triggers for updated_at

migrations/postgres/001_create_connectors.down.sql:
- Drop table

migrations/postgres/002_create_schedules.up.sql
migrations/postgres/003_create_exchange_configs.up.sql
migrations/postgres/004_create_alerts.up.sql

5. Create scripts/migrate.sh for running migrations

Please provide complete SQL migrations and Go implementation.
```

---

### FE-001 to FE-010: Frontend Setup

```
Set up the React frontend for the Data Collector.

Requirements:
1. Initialize Vite + React + TypeScript project:
   npm create vite@latest data-collector-frontend -- --template react-ts

2. Install dependencies:
   - tailwindcss, postcss, autoprefixer
   - @tanstack/react-query
   - zustand
   - axios
   - react-router-dom
   - react-hook-form, @hookform/resolvers, zod
   - recharts
   - lucide-react
   - @radix-ui/react-* (dialog, dropdown-menu, select, etc.)
   - clsx, tailwind-merge

3. Create project structure:
src/
├── app/
│   ├── App.tsx
│   ├── routes.tsx
│   └── providers.tsx
├── pages/
├── features/
├── components/
│   ├── ui/
│   ├── charts/
│   ├── layout/
│   └── common/
├── core/
│   ├── api/
│   ├── websocket/
│   ├── store/
│   └── config/
├── hooks/
├── utils/
├── types/
├── styles/
└── constants/

4. Configure:
   - Tailwind CSS with custom theme
   - Path aliases (@/ → src/)
   - TanStack Query client
   - Zustand store structure
   - API client with Axios
   - React Router with layout

5. Create base UI components:
   - Button, Input, Select, Modal, Toast, Badge, Card, Table

6. Create MainLayout with sidebar navigation

Please provide complete setup with all configuration files.
```

---

## Week 2: CCXT Integration & Exchange Management

### CC-001 to CC-010: CCXT Engine

```
Set up CCXT library for exchange connectivity in Go.

Requirements:
1. Research CCXT-Go options and choose the best approach:
   - go get github.com/ccxt/ccxt (if available)
   - Or use ccxt via goja (JS runtime)

2. Create internal/core/ccxt/types.go with:

type Exchange interface {
    ID() string
    Name() string
    FetchMarkets(ctx context.Context) ([]Market, error)
    FetchOHLCV(ctx context.Context, symbol, timeframe string, since int64, limit int) ([]OHLCV, error)
    FetchTimeframes() []string
    RateLimit() int
}

type Market struct {
    Symbol string
    Base   string
    Quote  string
    Active bool
}

type OHLCV struct {
    Timestamp int64
    Open      float64
    High      float64
    Low       float64
    Close     float64
    Volume    float64
}

3. Create internal/core/ccxt/engine.go with:
- Engine struct with exchange map
- GetExchange(id string) (Exchange, error)
- ListExchanges() []ExchangeInfo
- FetchOHLCV(ctx, exchangeID, symbol, timeframe, since, limit) ([]OHLCV, error)

4. Implement lazy loading of exchanges
5. Add exchange info caching
6. Create error types for exchange errors

Please provide complete implementation.
```

---

### EX-001 to EX-010: Exchange API Endpoints

```
Implement the Exchange API endpoints for the Data Collector.

Requirements:
1. Create internal/models/exchange.go:

type ExchangeInfo struct {
    ID          string   `json:"id"`
    Name        string   `json:"name"`
    Countries   []string `json:"countries"`
    URL         string   `json:"url"`
    RateLimit   int      `json:"rate_limit"`
    HasOHLCV    bool     `json:"has_ohlcv"`
    HasWebSocket bool    `json:"has_websocket"`
}

type TradingPair struct {
    Symbol   string `json:"symbol"`
    Base     string `json:"base"`
    Quote    string `json:"quote"`
    Active   bool   `json:"active"`
}

type ExchangeStatus struct {
    ID        string    `json:"id"`
    Available bool      `json:"available"`
    Latency   int64     `json:"latency_ms"`
    LastCheck time.Time `json:"last_check"`
}

2. Create internal/services/exchange/service.go:
- ExchangeService struct
- Methods: List, Get, GetPairs, GetTimeframes, GetStatus

3. Create internal/api/handlers/exchange.go:
- GET /api/v1/exchanges
- GET /api/v1/exchanges/:id
- GET /api/v1/exchanges/:id/pairs
- GET /api/v1/exchanges/:id/timeframes
- GET /api/v1/exchanges/:id/status

4. Add caching for exchange info (5 minute TTL)
5. Add query parameters for filtering

Please provide complete implementation.
```

---

### FE-EX-001 to FE-EX-010: Frontend Exchange Feature

```
Implement the Exchange feature for the Data Collector frontend.

Requirements:
1. Create src/features/exchanges/types.ts:

export interface Exchange {
  id: string;
  name: string;
  countries: string[];
  rateLimit: number;
  hasOHLCV: boolean;
  hasWebSocket: boolean;
}

export interface TradingPair {
  symbol: string;
  base: string;
  quote: string;
  active: boolean;
}

2. Create src/features/exchanges/api.ts with API functions

3. Create src/features/exchanges/hooks.ts:
- useExchanges()
- useExchange(id)
- useExchangePairs(exchangeId)
- useExchangeTimeframes(exchangeId)

4. Create components:
- ExchangeLogo.tsx (with fallback)
- ExchangeSelect.tsx
- PairSelect.tsx (with search)
- TimeframeSelect.tsx

Please provide complete TypeScript implementation.
```

---

## Week 3: Connector CRUD & Basic Data Collection

### CN-001 to CN-015: Connector Backend

```
Implement the Connector CRUD backend for the Data Collector.

Requirements:
1. Create internal/models/connector.go:

type ConnectorStatus string

const (
    StatusCreated ConnectorStatus = "created"
    StatusActive  ConnectorStatus = "active"
    StatusPaused  ConnectorStatus = "paused"
    StatusError   ConnectorStatus = "error"
)

type Connector struct {
    ID          uuid.UUID       `json:"id" db:"id"`
    Name        string          `json:"name" db:"name"`
    Exchange    string          `json:"exchange" db:"exchange"`
    Pairs       []string        `json:"pairs" db:"pairs"`
    Timeframes  []string        `json:"timeframes" db:"timeframes"`
    Schedule    *string         `json:"schedule,omitempty" db:"schedule"`
    Status      ConnectorStatus `json:"status" db:"status"`
    CreatedAt   time.Time       `json:"created_at" db:"created_at"`
    UpdatedAt   time.Time       `json:"updated_at" db:"updated_at"`
}

2. Create internal/repository/interfaces.go:

type ConnectorRepository interface {
    Create(ctx context.Context, connector *Connector) error
    GetByID(ctx context.Context, id uuid.UUID) (*Connector, error)
    List(ctx context.Context, filter ConnectorFilter) ([]*Connector, error)
    Update(ctx context.Context, connector *Connector) error
    Delete(ctx context.Context, id uuid.UUID) error
    UpdateStatus(ctx context.Context, id uuid.UUID, status ConnectorStatus) error
}

3. Create internal/repository/postgres/connector.go implementing the interface

4. Create internal/services/connector/service.go:
- Create, Get, List, Update, Delete
- Start, Stop, Refresh

5. Create internal/api/handlers/connector.go with all endpoints:
- POST /connectors
- GET /connectors
- GET /connectors/:id
- PUT /connectors/:id
- DELETE /connectors/:id
- POST /connectors/:id/start
- POST /connectors/:id/stop
- POST /connectors/:id/refresh

6. Create event bus for connector events

Please provide complete implementation with validation.
```

---

### FE-CN-001 to FE-CN-015: Connector Frontend

```
Implement the Connector frontend for the Data Collector.

Requirements:
1. Create src/features/connectors/types.ts with all types

2. Create src/features/connectors/api.ts with all API functions

3. Create src/features/connectors/hooks.ts:
- useConnectors()
- useConnector(id)
- useCreateConnector()
- useUpdateConnector()
- useDeleteConnector()
- useStartConnector()
- useStopConnector()

4. Create components:
- ConnectorCard.tsx
- ConnectorForm.tsx (with Zod validation)
- ConnectorStatus.tsx
- ConnectorActions.tsx

5. Create pages:
- src/pages/connectors/index.tsx (list)
- src/pages/connectors/create.tsx
- src/pages/connectors/[id].tsx (detail)

6. Implement filtering, search, and sorting

Please provide complete implementation with form validation.
```

---

## Week 4: MongoDB Storage & Data Deduplication

### ST-001 to ST-010: OHLCV Storage Implementation

```
Implement OHLCV storage with MongoDB for the Data Collector.

Requirements:
1. Create internal/models/ohlcv.go:

type OHLCV struct {
    Timestamp int64   `bson:"timestamp" json:"timestamp"`
    Open      float64 `bson:"open" json:"open"`
    High      float64 `bson:"high" json:"high"`
    Low       float64 `bson:"low" json:"low"`
    Close     float64 `bson:"close" json:"close"`
    Volume    float64 `bson:"volume" json:"volume"`
}

2. Create internal/repository/mongo/ohlcv.go:

type OHLCVRepository interface {
    Insert(ctx, exchange, pair, timeframe string, candle *OHLCV) error
    BulkUpsert(ctx, exchange, pair, timeframe string, candles []OHLCV) error
    Query(ctx, query OHLCVQuery) ([]OHLCV, error)
    GetLatest(ctx, exchange, pair, timeframe string) (*OHLCV, error)
    GetOldest(ctx, exchange, pair, timeframe string) (*OHLCV, error)
    Count(ctx, exchange, pair, timeframe string) (int64, error)
}

3. Implement collection naming strategy:
   Collection name format: ohlcv_{exchange}_{pair}_{timeframe}
   Example: ohlcv_binance_btc_usdt_1h

4. Create compound indexes for efficient queries

5. Implement BulkUpsert with deduplication

6. Create Metadata model and repository for tracking:
   - First/last timestamp
   - Candle count
   - Last update time

Please provide complete implementation with proper indexes.
```

---

### DC-001 to DC-010: Data Collection Service

```
Implement the Data Collection service for the Data Collector.

Requirements:
1. Create internal/models/job.go:

type JobType string
const (
    JobTypeBackfill    JobType = "backfill"
    JobTypeIncremental JobType = "incremental"
    JobTypeGapFill     JobType = "gap_fill"
)

type CollectionJob struct {
    ID          uuid.UUID   `json:"id"`
    ConnectorID uuid.UUID   `json:"connector_id"`
    Exchange    string      `json:"exchange"`
    Pair        string      `json:"pair"`
    Timeframe   string      `json:"timeframe"`
    Type        JobType     `json:"type"`
    Since       *int64      `json:"since,omitempty"`
    CreatedAt   time.Time   `json:"created_at"`
}

2. Create internal/services/collector/service.go:

type Service struct {
    ccxt         *ccxt.Engine
    ohlcvRepo    OHLCVRepository
    metadataRepo MetadataRepository
    eventBus     *events.Bus
}

Methods:
- StartConnector(ctx, connector *Connector) error
- StopConnector(ctx, connector *Connector) error
- RefreshConnector(ctx, connector *Connector) error
- ProcessJob(ctx, job *CollectionJob) error

3. Implement ProcessJob:
   a. Get metadata for exchange/pair/timeframe
   b. Determine 'since' timestamp
   c. Fetch OHLCV from CCXT
   d. Store candles in MongoDB
   e. Update metadata
   f. Emit events

4. Implement backfill logic for historical data

5. Add collection progress tracking

Please provide complete implementation with error handling.
```

---

## Common Utility Prompts

### Testing Prompt Template

```
Write comprehensive tests for [COMPONENT_NAME].

Requirements:
1. Unit tests for all public methods
2. Table-driven tests for edge cases
3. Mock external dependencies
4. Test error conditions
5. Achieve >80% code coverage

Test file location: [PATH]
Use testify for assertions: go get github.com/stretchr/testify

Please provide complete test file.
```

### Code Review Prompt

```
Review the following code for:
1. Go best practices and idioms
2. Error handling completeness
3. Potential race conditions
4. Memory leaks
5. Performance issues
6. Security vulnerabilities
7. Documentation completeness

[CODE TO REVIEW]

Please provide specific suggestions with code examples.
```

---

*Continue to PROMPTS-02-Core.md for Phase 2 prompts*
