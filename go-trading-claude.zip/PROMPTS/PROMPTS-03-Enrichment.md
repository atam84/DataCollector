# PROMPTS-03: Phase 3 - Enrichment

## Document Information

| Field | Value |
|-------|-------|
| **Phase** | 3 - Enrichment |
| **Weeks** | 9-12 |
| **Focus** | Indicator computation, WebSocket streaming, data explorer, charting, exports |

---

## Week 9: Indicator Computation Engine

### IC-001 to IC-013: Indicator Calculator Implementation

```
Implement technical indicator calculations for the Data Collector.

Requirements:
1. Create internal/services/indicator/calculator.go:

type Calculator struct {
    logger logger.Logger
}

2. Implement the following indicators:

// Simple Moving Average
func (c *Calculator) SMA(prices []float64, period int) []float64

// Exponential Moving Average  
func (c *Calculator) EMA(prices []float64, period int) []float64

// Relative Strength Index
func (c *Calculator) RSI(prices []float64, period int) []float64

// MACD (Moving Average Convergence Divergence)
func (c *Calculator) MACD(prices []float64, fastPeriod, slowPeriod, signalPeriod int) (macd, signal, histogram []float64)

// Bollinger Bands
func (c *Calculator) BollingerBands(prices []float64, period int, stdDev float64) (upper, middle, lower []float64)

// Average True Range
func (c *Calculator) ATR(high, low, close []float64, period int) []float64

// Stochastic Oscillator
func (c *Calculator) Stochastic(high, low, close []float64, kPeriod, dPeriod, smooth int) (k, d []float64)

// Average Directional Index
func (c *Calculator) ADX(high, low, close []float64, period int) []float64

// On-Balance Volume
func (c *Calculator) OBV(close, volume []float64) []float64

// Volume Weighted Average Price
func (c *Calculator) VWAP(high, low, close, volume []float64) []float64

3. Implementation guidelines:
- Handle edge cases (insufficient data)
- Return nil for invalid inputs
- Optimize for performance

4. Create indicator definitions with parameters

5. Write unit tests with known values (verify against TradingView)

Please provide complete implementation for all indicators.
```

---

### IS-001 to IS-011: Indicator Service Implementation

```
Implement the Indicator Service for computing and storing indicators.

Requirements:
1. Create internal/models/indicator.go:

type IndicatorData struct {
    Timestamp int64              `bson:"timestamp" json:"timestamp"`
    Values    map[string]float64 `bson:"values" json:"values"`
}

type IndicatorConfig struct {
    ID         uuid.UUID              `json:"id"`
    Name       string                 `json:"name"`
    Type       IndicatorType          `json:"type"`
    Parameters map[string]interface{} `json:"parameters"`
    Enabled    bool                   `json:"enabled"`
}

2. Create internal/repository/mongo/indicator.go:

type IndicatorRepository interface {
    Store(ctx, exchange, pair, timeframe string, data []IndicatorData) error
    Query(ctx, query IndicatorQuery) ([]IndicatorData, error)
    DeleteRange(ctx, exchange, pair, timeframe string, start, end int64) error
}

3. Create internal/services/indicator/service.go:

type Service struct {
    calculator    *Calculator
    ohlcvRepo     OHLCVRepository
    indicatorRepo IndicatorRepository
    configRepo    IndicatorConfigRepository
    jobQueue      *queue.JobQueue
}

Methods:
- ComputeForRange(ctx, exchange, pair, timeframe string, start, end int64) error
- RecomputeAll(ctx, exchange, pair, timeframe string) error
- GetConfig(ctx) ([]IndicatorConfig, error)
- UpdateConfig(ctx, config IndicatorConfig) error

4. Implement automatic computation after new candles

5. Create API endpoints:
- GET /api/v1/indicators
- POST /api/v1/indicators/compute
- GET /api/v1/indicators/config
- PUT /api/v1/indicators/config

Please provide complete implementation.
```

---

## Week 10: WebSocket Real-time Streaming

### WS-001 to WS-012: WebSocket Server Implementation

```
Implement WebSocket server for real-time data streaming.

Requirements:
1. Install gorilla/websocket: go get github.com/gorilla/websocket
2. Create internal/api/websocket/hub.go:

type Hub struct {
    clients    map[*Client]bool
    rooms      map[string]map[*Client]bool
    broadcast  chan *Message
    register   chan *Client
    unregister chan *Client
    mu         sync.RWMutex
}

func NewHub() *Hub
func (h *Hub) Run()
func (h *Hub) BroadcastToRoom(room string, msg *Message)

3. Create internal/api/websocket/client.go:

type Client struct {
    hub           *Hub
    conn          *websocket.Conn
    send          chan []byte
    subscriptions map[string]bool
}

func NewClient(hub *Hub, conn *websocket.Conn) *Client
func (c *Client) ReadPump()
func (c *Client) WritePump()
func (c *Client) Subscribe(room string)
func (c *Client) Unsubscribe(room string)

4. Create message types:

type MessageType string
const (
    MsgTypeSubscribe   MessageType = "subscribe"
    MsgTypeUnsubscribe MessageType = "unsubscribe"
    MsgTypeOHLCV       MessageType = "ohlcv"
    MsgTypeStatus      MessageType = "status"
    MsgTypePing        MessageType = "ping"
    MsgTypePong        MessageType = "pong"
)

type Message struct {
    Type      MessageType     `json:"type"`
    Channel   string          `json:"channel,omitempty"`
    Exchange  string          `json:"exchange,omitempty"`
    Symbol    string          `json:"symbol,omitempty"`
    Timeframe string          `json:"timeframe,omitempty"`
    Data      json.RawMessage `json:"data,omitempty"`
}

5. Implement heartbeat/ping-pong
6. Handle reconnection
7. Integrate with event bus for broadcasting updates

Please provide complete implementation.
```

---

### FE-WS-001 to FE-WS-009: Frontend WebSocket Integration

```
Implement WebSocket client for the Data Collector frontend.

Requirements:
1. Install: npm install reconnecting-websocket
2. Create src/core/websocket/client.ts:

class WebSocketClient {
  private ws: ReconnectingWebSocket | null = null;
  private subscriptions: Map<string, Subscription> = new Map();
  private isConnected = false;

  connect(): void
  disconnect(): void
  subscribe(channel: string, params: Record<string, string>, handler: MessageHandler): () => void
  onConnectionChange(listener: (connected: boolean) => void): () => void
}

export const wsClient = new WebSocketClient();

3. Create src/core/websocket/hooks.ts:

export function useWebSocket<T>(
  channel: string,
  params: Record<string, string>,
  enabled?: boolean
): T | undefined

export function useWebSocketConnection(): boolean

4. Create feature hooks:

export function useRealtimeOHLCV(exchange: string, pair: string, timeframe: string): OHLCV | undefined

export function useRealtimeConnectorStatus(connectorId: string): StatusUpdate | undefined

5. Create ConnectionStatus component

6. Integrate with Zustand store for real-time data

7. Connect WebSocket on app mount

Please provide complete implementation.
```

---

## Week 11: Data Explorer & Charting

### DA-001 to DA-008: Data API Implementation

```
Implement Data API for querying OHLCV and indicator data.

Requirements:
1. Create internal/services/data/service.go:

type Service struct {
    ohlcvRepo     OHLCVRepository
    indicatorRepo IndicatorRepository
    metadataRepo  MetadataRepository
    cache         *cache.Cache
}

Methods:
- QueryOHLCV(ctx, query OHLCVQuery) (*OHLCVResponse, error)
- QueryIndicators(ctx, query IndicatorQuery) (*IndicatorResponse, error)
- GetCoverage(ctx, exchange, pair, timeframe string) (*Coverage, error)

2. Create response types:

type OHLCVResponse struct {
    Data       []OHLCV `json:"data"`
    Count      int     `json:"count"`
    HasMore    bool    `json:"has_more"`
    NextCursor string  `json:"next_cursor,omitempty"`
}

type Coverage struct {
    Exchange        string    `json:"exchange"`
    Pair            string    `json:"pair"`
    Timeframe       string    `json:"timeframe"`
    FirstTimestamp  int64     `json:"first_timestamp"`
    LastTimestamp   int64     `json:"last_timestamp"`
    CandleCount     int64     `json:"candle_count"`
    CoveragePercent float64   `json:"coverage_percent"`
    Gaps            []GapInfo `json:"gaps"`
}

3. Create API endpoints:

GET /api/v1/data/ohlcv
Query parameters:
- exchange, pair, timeframe (required)
- start, end (timestamps)
- limit (default 500, max 5000)
- order (asc/desc)
- indicators (comma-separated)
- cursor (for pagination)

GET /api/v1/data/coverage

4. Implement cursor-based pagination
5. Add response compression

Please provide complete implementation.
```

---

### CH-001 to CH-012: Chart Components Implementation

```
Implement chart components for the Data Explorer.

Requirements:
1. Create src/components/charts/ChartContainer.tsx:
   - Title bar with toolbar
   - Loading overlay
   - Error state
   - Responsive container

2. Create src/components/charts/CandlestickChart.tsx:

interface CandlestickChartProps {
  data: OHLCVWithIndicators[];
  height?: number;
  indicators?: {
    sma?: { enabled: boolean; periods: number[] };
    ema?: { enabled: boolean; periods: number[] };
    bollinger?: { enabled: boolean };
  };
  showVolume?: boolean;
  onCandleClick?: (candle: OHLCV) => void;
}

Use Recharts:
- ComposedChart with Bar for candlesticks
- Line for indicators
- Custom candlestick shape component
- Synchronized tooltip

3. Create custom Candlestick shape for Recharts

4. Create VolumeChart.tsx (synchronized with price)

5. Create IndicatorChart.tsx:
   - RSI with overbought/oversold lines
   - MACD with histogram
   - Stochastic

6. Create ChartTooltip.tsx with OHLCV data

7. Implement zoom and pan functionality

8. Optimize for large datasets with downsampling

Please provide complete implementation with Recharts.
```

---

### FE-EP-001 to FE-EP-010: Explorer Page Implementation

```
Implement the Data Explorer page.

Requirements:
1. Create src/pages/explorer/index.tsx with layout:
   - Filter bar
   - Chart area
   - Indicator panel
   - Data table (toggle)

2. Create DataFilters.tsx:
   - Cascading dropdowns (exchange → pairs → timeframes)
   - Date range picker with presets
   - Apply/Reset buttons

3. Create IndicatorPanel.tsx:
   - Checkbox for each indicator
   - Parameter configuration
   - Presets (Default, Trend, Momentum)

4. Create CoverageInfo.tsx:
   - First/Last date
   - Total candles
   - Coverage percentage
   - Gaps count

5. Create DataTable.tsx:
   - Sortable columns
   - Virtual scrolling for large datasets
   - Column visibility toggle

6. Implement view toggle (Chart/Table)

7. Implement infinite scroll for data loading

8. Add URL state synchronization for filters

Please provide complete implementation.
```

---

## Week 12: Export Functionality

### EXP-001 to EXP-012: Export Backend Implementation

```
Implement data export functionality.

Requirements:
1. Create internal/models/export.go:

type ExportStatus string
const (
    ExportStatusPending    ExportStatus = "pending"
    ExportStatusProcessing ExportStatus = "processing"
    ExportStatusCompleted  ExportStatus = "completed"
    ExportStatusFailed     ExportStatus = "failed"
)

type ExportFormat string
const (
    ExportFormatCSV     ExportFormat = "csv"
    ExportFormatJSON    ExportFormat = "json"
    ExportFormatParquet ExportFormat = "parquet"
)

type Export struct {
    ID          uuid.UUID    `json:"id"`
    Format      ExportFormat `json:"format"`
    Exchange    string       `json:"exchange"`
    Pair        string       `json:"pair"`
    Timeframe   string       `json:"timeframe"`
    StartTime   int64        `json:"start_time"`
    EndTime     int64        `json:"end_time"`
    Indicators  []string     `json:"indicators"`
    Status      ExportStatus `json:"status"`
    FilePath    string       `json:"file_path,omitempty"`
    FileSize    int64        `json:"file_size,omitempty"`
    RowCount    int64        `json:"row_count,omitempty"`
    CreatedAt   time.Time    `json:"created_at"`
    ExpiresAt   time.Time    `json:"expires_at"`
}

2. Create internal/services/export/service.go:

Methods:
- Create(ctx, req CreateExportRequest) (*Export, error)
- Get(ctx, id uuid.UUID) (*Export, error)
- Download(ctx, id uuid.UUID) (io.ReadCloser, error)
- ProcessExport(ctx, export *Export) error

3. Implement exporters:
   - CSV with streaming
   - JSON with streaming
   - Parquet (using parquet-go)

4. Create API endpoints:
- POST /api/v1/data/export
- GET /api/v1/data/export/:id
- GET /api/v1/data/export/:id/download
- GET /api/v1/data/exports

5. Implement async processing with job queue
6. Implement file cleanup for expired exports

Please provide complete implementation.
```

---

### FE-EXP-001 to FE-EXP-008: Export Frontend Implementation

```
Implement Export UI for the Data Collector frontend.

Requirements:
1. Create src/features/exports/types.ts
2. Create src/features/exports/api.ts
3. Create src/features/exports/hooks.ts:
- useCreateExport()
- useExport(id)
- useExports()

4. Create ExportModal.tsx:
   - Format selection (CSV, JSON, Parquet)
   - Date range (pre-filled from explorer)
   - Indicator selection
   - Export button

5. Create ExportProgress.tsx:
   - Real-time status polling
   - Progress bar
   - Download when ready

6. Create ExportHistory.tsx:
   - List of exports with status
   - Download button
   - Delete button

7. Implement download handling

Please provide complete implementation.
```

---

*Continue to PROMPTS-04-Polish.md for Phase 4 prompts*
