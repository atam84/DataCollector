# PROMPTS-02: Phase 2 - Core Features

## Document Information

| Field | Value |
|-------|-------|
| **Phase** | 2 - Core Features |
| **Weeks** | 5-8 |
| **Focus** | Rate limiting, job scheduling, gap detection, error handling, dashboard |

---

## Week 5: Rate Limiting & Job Scheduling

### RL-001 to RL-008: Rate Limiter Implementation

```
Implement a rate limiting system for exchange API calls.

Requirements:
1. Create internal/core/ratelimit/bucket.go:

type TokenBucket struct {
    tokens     float64
    maxTokens  float64
    refillRate float64 // tokens per second
    lastRefill time.Time
    mu         sync.Mutex
}

Methods:
- NewTokenBucket(maxTokens float64, refillRate float64) *TokenBucket
- Acquire(ctx context.Context) error - blocks until token available
- TryAcquire() bool - non-blocking
- Available() float64

2. Create internal/core/ratelimit/manager.go:

type Manager struct {
    buckets   map[string]*TokenBucket
    configs   map[string]*ExchangeConfig
    mu        sync.RWMutex
}

type ExchangeConfig struct {
    Exchange       string
    RequestsPerMin int
    BurstSize      int
}

Methods:
- NewManager(configs []ExchangeConfig) *Manager
- Acquire(ctx context.Context, exchange string) error
- GetConfig(exchange string) *ExchangeConfig
- LoadFromCCXT(engine *ccxt.Engine) error

3. Load exchange rate limits from CCXT rateLimit property
4. Implement per-exchange rate limiting
5. Add metrics for rate limit waits
6. Integrate with collector service

Please provide complete implementation with thread safety.
```

---

### JQ-001 to JQ-008: Job Queue Implementation

```
Implement a priority job queue for data collection jobs.

Requirements:
1. Create internal/core/queue/priority_queue.go:

type Job interface {
    GetID() uuid.UUID
    GetPriority() int
    GetCreatedAt() time.Time
}

// Implement heap.Interface for priority queue
type jobHeap []Job

2. Create internal/core/queue/queue.go:

type JobQueue struct {
    heap       *jobHeap
    cond       *sync.Cond
    workers    int
    handler    func(context.Context, Job) error
    running    bool
}

Methods:
- NewJobQueue(workers int, handler func(context.Context, Job) error) *JobQueue
- Start(ctx context.Context)
- Stop() // graceful shutdown
- Enqueue(job Job)
- Size() int
- Clear()

3. Implement worker pool with configurable workers
4. Implement graceful shutdown that waits for in-progress jobs
5. Add job retry logic with exponential backoff
6. Add metrics for queue size and processing time

Please provide complete implementation with graceful shutdown.
```

---

### SC-001 to SC-008: Scheduler Implementation

```
Implement a cron-based scheduler for data collection.

Requirements:
1. Install go-cron: go get github.com/robfig/cron/v3
2. Create internal/services/scheduler/service.go:

type Service struct {
    cron         *cron.Cron
    connectorSvc *connector.Service
    collectorSvc *collector.Service
    repo         ScheduleRepository
    schedules    map[uuid.UUID]cron.EntryID
    mu           sync.RWMutex
}

Methods:
- NewService(deps...) *Service
- Start() - start the cron scheduler
- Stop() - stop gracefully
- Schedule(connector *Connector) error
- Unschedule(connectorID uuid.UUID) error
- GetNextRun(connectorID uuid.UUID) *time.Time
- RestoreSchedules(ctx context.Context) error

3. Create internal/models/schedule.go:

type Schedule struct {
    ID          uuid.UUID  `db:"id"`
    ConnectorID uuid.UUID  `db:"connector_id"`
    CronExpr    string     `db:"cron_expr"`
    NextRun     *time.Time `db:"next_run"`
    LastRun     *time.Time `db:"last_run"`
    Enabled     bool       `db:"enabled"`
}

4. Implement schedule persistence
5. Restore schedules on startup
6. Add schedule validation (minimum interval)

Please provide complete implementation with persistence.
```

---

## Week 6: Gap Detection & Error Handling

### GD-001 to GD-010: Gap Detection Implementation

```
Implement gap detection for OHLCV data.

Requirements:
1. Create internal/models/gap.go:

type Gap struct {
    ID           uuid.UUID `bson:"_id" json:"id"`
    Exchange     string    `bson:"exchange" json:"exchange"`
    Pair         string    `bson:"pair" json:"pair"`
    Timeframe    string    `bson:"timeframe" json:"timeframe"`
    StartTime    int64     `bson:"start_time" json:"start_time"`
    EndTime      int64     `bson:"end_time" json:"end_time"`
    MissingCount int64     `bson:"missing_count" json:"missing_count"`
    Status       GapStatus `bson:"status" json:"status"`
    DetectedAt   time.Time `bson:"detected_at" json:"detected_at"`
}

type GapStatus string
const (
    GapStatusDetected GapStatus = "detected"
    GapStatusFilling  GapStatus = "filling"
    GapStatusFilled   GapStatus = "filled"
)

2. Create internal/core/gap/detector.go:

type Detector struct {
    logger logger.Logger
}

Methods:
- Detect(candles []OHLCV, timeframe string) []Gap
- GetExpectedInterval(timeframe string) time.Duration
- CalculateMissingCount(start, end int64, interval time.Duration) int64

3. Implement detection algorithm:
   - Compare consecutive timestamps
   - Account for expected interval based on timeframe
   - Allow small tolerance for variations

4. Create gap repository for storing detected gaps

5. Integrate with collector service:
   - Detect gaps after each fetch
   - Store detected gaps
   - Create GapFill jobs for new gaps

6. Create GET /api/v1/data/gaps endpoint

Please provide complete implementation.
```

---

### CB-001 to CB-007: Circuit Breaker Implementation

```
Implement a circuit breaker pattern for exchange API calls.

Requirements:
1. Create internal/core/circuit/breaker.go:

type State int
const (
    StateClosed   State = iota // Normal operation
    StateOpen                   // Failing, reject requests
    StateHalfOpen              // Testing if recovered
)

type Breaker struct {
    name          string
    maxFailures   int
    timeout       time.Duration
    halfOpenMax   int
    state         State
    failures      int
    successes     int
    lastFailure   time.Time
    mu            sync.RWMutex
}

type Config struct {
    MaxFailures   int
    Timeout       time.Duration
    HalfOpenMax   int
}

Methods:
- NewBreaker(name string, config Config) *Breaker
- Execute(fn func() error) error
- AllowRequest() bool
- RecordSuccess()
- RecordFailure()
- State() State
- Reset()

2. Implement state transitions:
   - Closed → Open: after maxFailures
   - Open → HalfOpen: after timeout
   - HalfOpen → Closed: after halfOpenMax successes
   - HalfOpen → Open: on failure

3. Create circuit breaker registry for per-exchange breakers

4. Integrate with CCXT Engine

5. Add metrics for circuit breaker state

Please provide complete implementation with proper state management.
```

---

### EH-001 to EH-007: Error Handling Implementation

```
Implement comprehensive error handling for the Data Collector.

Requirements:
1. Create internal/core/errors/errors.go:

type Error struct {
    Code    ErrorCode
    Message string
    Err     error
    Context map[string]interface{}
}

type ErrorCode string
const (
    ErrCodeInternal       ErrorCode = "INTERNAL_ERROR"
    ErrCodeNotFound       ErrorCode = "NOT_FOUND"
    ErrCodeValidation     ErrorCode = "VALIDATION_ERROR"
    ErrCodeRateLimit      ErrorCode = "RATE_LIMIT_EXCEEDED"
    ErrCodeExchangeError  ErrorCode = "EXCHANGE_ERROR"
    ErrCodeTimeout        ErrorCode = "TIMEOUT"
    ErrCodeCircuitOpen    ErrorCode = "CIRCUIT_OPEN"
)

func NewError(code ErrorCode, message string) *Error
func WrapError(err error, code ErrorCode, message string) *Error

2. Create exchange-specific errors

3. Create internal/core/errors/retry.go:

type RetryConfig struct {
    MaxAttempts     int
    InitialDelay    time.Duration
    MaxDelay        time.Duration
    Multiplier      float64
    RetryableErrors []ErrorCode
}

func Retry(ctx context.Context, config RetryConfig, fn func() error) error

4. Implement exponential backoff with jitter

5. Integrate with collector service

6. Create API error response format

Please provide complete implementation.
```

---

## Week 7: Frontend Connector Management

### FE-CL-001 to FE-CL-010: Connector List Page

```
Implement the Connector List page for the Data Collector frontend.

Requirements:
1. Create src/pages/connectors/index.tsx with:
   - Page header with "New Connector" button
   - Filter bar (exchange, status, search)
   - Connector cards grid/list view
   - Pagination
   - Bulk action bar

2. Create src/pages/connectors/components/ConnectorFilters.tsx:
   - Exchange dropdown
   - Status dropdown
   - Debounced search input
   - Clear filters button
   - URL state sync

3. Create src/pages/connectors/components/ConnectorList.tsx:
   - Grid and list view modes
   - Checkbox selection for bulk actions
   - Loading skeletons
   - Empty state

4. Create src/pages/connectors/components/ConnectorCard.tsx:
   - Name and exchange with logo
   - Status badge
   - Pairs count with tooltip
   - Timeframes
   - Last sync time
   - Actions dropdown

5. Create src/pages/connectors/components/BulkActions.tsx:
   - Start All / Stop All
   - Delete selected
   - Clear selection

6. Implement responsive design

Please provide complete implementation.
```

---

### FE-CD-001 to FE-CD-010: Connector Detail Page

```
Implement the Connector Detail page for the Data Collector frontend.

Requirements:
1. Create src/pages/connectors/[id].tsx with sections:
   - Header with name, status, actions
   - Configuration panel
   - Statistics panel
   - Collection history
   - Detected gaps

2. Create ConnectorHeader.tsx:
   - Back button
   - Connector name (editable)
   - Exchange with logo
   - Status badge
   - Action buttons (Start/Stop, Refresh, Edit, Delete)

3. Create ConnectorConfig.tsx:
   - View mode: display all settings
   - Edit mode: editable form

4. Create ConnectorStats.tsx:
   - Total candles
   - Date range
   - Coverage percentage
   - Gaps count
   - Last sync time
   - Next scheduled run

5. Create CollectionHistory.tsx:
   - Table with timestamp, pairs, count, status
   - Pagination
   - Filter by status

6. Create GapsList.tsx:
   - Gap date range
   - Missing count
   - Status
   - "Fill Now" button

7. Implement edit mode with save/cancel

Please provide complete implementation.
```

---

## Week 8: Dashboard & Basic Stats

### SS-001 to SS-008: System Stats API

```
Implement System Stats API for the Data Collector dashboard.

Requirements:
1. Create internal/models/stats.go:

type SystemStats struct {
    ActiveConnectors   int       `json:"active_connectors"`
    TotalConnectors    int       `json:"total_connectors"`
    TotalPairs         int       `json:"total_pairs"`
    TotalCandles       int64     `json:"total_candles"`
    GapsDetected       int       `json:"gaps_detected"`
    GapsPending        int       `json:"gaps_pending"`
    CollectionRate     float64   `json:"collection_rate_per_hour"`
    LastCollectionTime *time.Time `json:"last_collection_time"`
}

type ExchangeHealth struct {
    Exchange     string  `json:"exchange"`
    Available    bool    `json:"available"`
    LatencyMs    int64   `json:"latency_ms"`
    SuccessRate  float64 `json:"success_rate"`
    CircuitState string  `json:"circuit_state"`
}

type CollectionActivity struct {
    Timestamp time.Time `json:"timestamp"`
    Candles   int64     `json:"candles"`
    Successes int       `json:"successes"`
    Failures  int       `json:"failures"`
}

2. Create internal/services/stats/service.go:
- GetSystemStats(ctx) (*SystemStats, error)
- GetExchangeHealth(ctx) ([]ExchangeHealth, error)
- GetCollectionActivity(ctx, hours int) ([]CollectionActivity, error)
- GetRunningJobs(ctx) ([]JobInfo, error)

3. Implement caching for expensive queries (30 second TTL)

4. Create API endpoints:
- GET /api/v1/system/status
- GET /api/v1/system/stats
- GET /api/v1/system/jobs
- GET /api/v1/system/activity?hours=24

Please provide complete implementation with caching.
```

---

### FE-DB-001 to FE-DB-010: Dashboard Frontend

```
Implement the Dashboard page for the Data Collector frontend.

Requirements:
1. Create src/pages/dashboard/index.tsx with layout:
   - Stats cards row (4 cards)
   - Activity chart (full width)
   - Two columns: Recent jobs, Exchange health

2. Create src/features/system/hooks.ts:
- useSystemStats()
- useExchangeHealth()
- useCollectionActivity(hours)
- useRunningJobs()

3. Create StatsCards.tsx:
   - Active Connectors
   - Total Pairs
   - Data Points (formatted)
   - Gaps Detected
   Each with icon, value, label, trend

4. Create ActivityChart.tsx:
   - Area chart with Recharts
   - Time range selector (6h, 12h, 24h, 7d)
   - Custom tooltip
   - Loading skeleton

5. Create RecentJobs.tsx:
   - Job list with status icons
   - Exchange and pair
   - Started time (relative)
   - Candles count
   - Auto-refresh every 5 seconds

6. Create ExchangeHealth.tsx:
   - Exchange name with logo
   - Status indicator (green/yellow/red)
   - Latency bar
   - Success rate
   - Circuit state badge

7. Add auto-refresh for all data

Please provide complete implementation.
```

---

## Common Prompts for Phase 2

### Integration Testing Prompt

```
Write integration tests for [COMPONENT] that test the full flow.

Requirements:
1. Set up test database (use testcontainers)
2. Create test fixtures
3. Test happy path scenarios
4. Test error scenarios
5. Clean up after tests

Please provide complete test file.
```

### Performance Testing Prompt

```
Create a performance test for [COMPONENT].

Requirements:
1. Use k6 or Go's testing.B for benchmarks
2. Test with realistic data volumes
3. Measure throughput, latency (p50, p95, p99)
4. Test normal load, peak load, sustained load

Please provide the test script and expected baselines.
```

---

*Continue to PROMPTS-03-Enrichment.md for Phase 3 prompts*
